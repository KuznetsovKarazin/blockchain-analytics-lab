All 54 predeclared method/policy/budget cells. B=5 with count or semantic 1/20 is primary; semantic 1/10 and B=1,20 are sensitivities. Notification counts are totals over each 30-day window.

| Case | Method | Policy | B/day | Role | Exact notified / known references | Unresolved observation evidence | Notifications | Unadjudicated notifications |
|---|---|---|---:|---|---:|---:|---:|---:|
| LiFi | core_count_60s_10 | greedy | 1 | Sensitivity | 1/1 | 0 | 1 | 0 |
| LiFi | core_count_60s_10 | greedy | 5 | Primary | 1/1 | 0 | 1 | 0 |
| LiFi | core_count_60s_10 | greedy | 20 | Sensitivity | 1/1 | 0 | 1 | 0 |
| LiFi | core_count_60s_10 | paced_cumulative | 1 | Sensitivity | 1/1 | 0 | 1 | 0 |
| LiFi | core_count_60s_10 | paced_cumulative | 5 | Primary | 1/1 | 0 | 1 | 0 |
| LiFi | core_count_60s_10 | paced_cumulative | 20 | Sensitivity | 1/1 | 0 | 1 | 0 |
| LiFi | core_count_60s_10 | token_bucket | 1 | Sensitivity | 1/1 | 0 | 1 | 0 |
| LiFi | core_count_60s_10 | token_bucket | 5 | Primary | 1/1 | 0 | 1 | 0 |
| LiFi | core_count_60s_10 | token_bucket | 20 | Sensitivity | 1/1 | 0 | 1 | 0 |
| LiFi | outflow_rank_1_20 | greedy | 1 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_20 | greedy | 5 | Primary | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_20 | greedy | 20 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_20 | paced_cumulative | 1 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_20 | paced_cumulative | 5 | Primary | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_20 | paced_cumulative | 20 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_20 | token_bucket | 1 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_20 | token_bucket | 5 | Primary | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_20 | token_bucket | 20 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_10 | greedy | 1 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_10 | greedy | 5 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_10 | greedy | 20 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_10 | paced_cumulative | 1 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_10 | paced_cumulative | 5 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_10 | paced_cumulative | 20 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_10 | token_bucket | 1 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_10 | token_bucket | 5 | Sensitivity | 0/1 | 0 | 0 | 0 |
| LiFi | outflow_rank_1_10 | token_bucket | 20 | Sensitivity | 0/1 | 0 | 0 | 0 |
| Revest | core_count_60s_10 | greedy | 1 | Sensitivity | 0/2 | 0 | 2 | 2 |
| Revest | core_count_60s_10 | greedy | 5 | Primary | 0/2 | 0 | 2 | 2 |
| Revest | core_count_60s_10 | greedy | 20 | Sensitivity | 0/2 | 0 | 2 | 2 |
| Revest | core_count_60s_10 | paced_cumulative | 1 | Sensitivity | 0/2 | 0 | 2 | 2 |
| Revest | core_count_60s_10 | paced_cumulative | 5 | Primary | 0/2 | 0 | 2 | 2 |
| Revest | core_count_60s_10 | paced_cumulative | 20 | Sensitivity | 0/2 | 0 | 2 | 2 |
| Revest | core_count_60s_10 | token_bucket | 1 | Sensitivity | 0/2 | 0 | 2 | 2 |
| Revest | core_count_60s_10 | token_bucket | 5 | Primary | 0/2 | 0 | 2 | 2 |
| Revest | core_count_60s_10 | token_bucket | 20 | Sensitivity | 0/2 | 0 | 2 | 2 |
| Revest | outflow_rank_1_20 | greedy | 1 | Sensitivity | 0/2 | 0 | 0 | 0 |
| Revest | outflow_rank_1_20 | greedy | 5 | Primary | 0/2 | 0 | 0 | 0 |
| Revest | outflow_rank_1_20 | greedy | 20 | Sensitivity | 0/2 | 0 | 0 | 0 |
| Revest | outflow_rank_1_20 | paced_cumulative | 1 | Sensitivity | 0/2 | 0 | 0 | 0 |
| Revest | outflow_rank_1_20 | paced_cumulative | 5 | Primary | 0/2 | 0 | 0 | 0 |
| Revest | outflow_rank_1_20 | paced_cumulative | 20 | Sensitivity | 0/2 | 0 | 0 | 0 |
| Revest | outflow_rank_1_20 | token_bucket | 1 | Sensitivity | 0/2 | 0 | 0 | 0 |
| Revest | outflow_rank_1_20 | token_bucket | 5 | Primary | 0/2 | 0 | 0 | 0 |
| Revest | outflow_rank_1_20 | token_bucket | 20 | Sensitivity | 0/2 | 0 | 0 | 0 |
| Revest | outflow_rank_1_10 | greedy | 1 | Sensitivity | 0/2 | 0 | 1 | 1 |
| Revest | outflow_rank_1_10 | greedy | 5 | Sensitivity | 0/2 | 0 | 2 | 2 |
| Revest | outflow_rank_1_10 | greedy | 20 | Sensitivity | 0/2 | 0 | 2 | 2 |
| Revest | outflow_rank_1_10 | paced_cumulative | 1 | Sensitivity | 0/2 | 0 | 1 | 1 |
| Revest | outflow_rank_1_10 | paced_cumulative | 5 | Sensitivity | 0/2 | 0 | 2 | 2 |
| Revest | outflow_rank_1_10 | paced_cumulative | 20 | Sensitivity | 0/2 | 0 | 2 | 2 |
| Revest | outflow_rank_1_10 | token_bucket | 1 | Sensitivity | 0/2 | 0 | 1 | 1 |
| Revest | outflow_rank_1_10 | token_bucket | 5 | Sensitivity | 0/2 | 0 | 1 | 1 |
| Revest | outflow_rank_1_10 | token_bucket | 20 | Sensitivity | 0/2 | 0 | 2 | 2 |

Zero unresolved observation evidence applies only to the verified known references; it does not resolve the two additional candidate roles or establish complete incident inventories.

Independent interpretation audit SHA256: `3fcabd6a7fc18f79f88964ecc6398cd1707297ee92c3855ed6b13a37946060db`.
