Primary comparison: B=5 offered per UTC day. Each load is the total over the full 30-day case window. Fractions describe verified known reference executions; both inventories remain known subsets.

| Case | Policy | Count notified / known references | Semantic 1/20 notified / known references | Count notifications | Semantic notifications |
|---|---|---:|---:|---:|---:|
| LiFi | greedy | 1/1 | 0/1 | 1 | 0 |
| LiFi | paced_cumulative | 1/1 | 0/1 | 1 | 0 |
| LiFi | token_bucket | 1/1 | 0/1 | 1 | 0 |
| Revest | greedy | 0/2 | 0/2 | 2 | 0 |
| Revest | paced_cumulative | 0/2 | 0/2 | 2 | 0 |
| Revest | token_bucket | 0/2 | 0/2 | 2 | 0 |

LiFi count establishes an exact-reference incident hit. Other no-hit cells remain indeterminate for incident coverage because the inventories are not established complete. The two Revest count notifications have unknown attack status; they are not labelled false positives.

Independent interpretation audit SHA256: `3fcabd6a7fc18f79f88964ecc6398cd1707297ee92c3855ed6b13a37946060db`.
